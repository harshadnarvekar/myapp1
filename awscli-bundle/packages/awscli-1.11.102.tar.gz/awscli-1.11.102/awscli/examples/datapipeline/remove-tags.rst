**To remove a tag from a pipeline**

This example removes the specified tag from the specified pipeline::

   aws datapipeline remove-tags --pipeline-id df-00627471SOVYZEXAMPLE --tag-keys environment
